## Imports
from flask import Flask, render_template
from clustercounter.clustercounter_frontend import clustercounter


## Browser session

application = Flask(__name__)
application.register_blueprint(clustercounter, url_prefix= "/clustercounter")

# Homepage
@application.route("/")
def homepage():
    return render_template("homepage.html")


